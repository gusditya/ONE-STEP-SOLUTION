import "./Card.css";

export default function Card() {
    return (
        <div className="Card-Pengalaman">
            <div className="Title-pengalaman">
                <h2 className="font-bold text-2xl">Kisah Sukses Alumni OSS</h2>
            </div>

            <div className="PeopleCard">
                <div className="Container1-CardPeople">
                    
                </div>

                <div className="Container2-CardPeople">

                </div>

                <div className="Container3-CardPeople">

                </div>

                <div className="Container4-CardPeople">

                </div>
            </div>
        </div>
    )
}
